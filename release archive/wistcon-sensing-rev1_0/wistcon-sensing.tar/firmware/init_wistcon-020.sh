#!/bin/sh
# This shell script should enable the device tree overlay
#for EL-100-020-001 DIN-Rail-controller rev_2
# strasys.at
# Johannes Strasser
# July 4th 2017

#slots="/sys/devices/bone_capemgr.9/slots"
#echo strasys-wistcon >$slots

/usr/lib/cgi-bin/firmware

